// ops.institutions.revokeInviteCode: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/revokeInviteCode.ts; the router and catalog are generated.
import { ORPCError } from '@orpc/server';
import type { RevokeInviteCodeInput, RevokeInviteCodeResult } from '@repo/core/api/v1/contract';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

export async function run(
  db: PoolClient,
  accountId: string,
  input: RevokeInviteCodeInput,
): Promise<RevokeInviteCodeResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const updated = await db.query(
    `UPDATE public.invite_codes SET is_active = false WHERE id = $1 AND school_id = $2 AND is_active = true`,
    [input.codeId, input.schoolId],
  );
  if (updated.rowCount === 1) return { success: true };

  // Nothing was revoked: either the code is not one of this school's codes, or it is already inactive.
  const existing = await db.query(
    `SELECT is_active FROM public.invite_codes WHERE id = $1 AND school_id = $2`,
    [input.codeId, input.schoolId],
  );
  if (existing.rowCount === 0 || existing.rows.length === 0) {
    throw new ORPCError('NOT_FOUND', { message: 'No invite code with that id exists for this school.' });
  }
  throw new ORPCError('CONFLICT', { message: 'This invite code is already inactive.' });
}
