import { z } from 'zod';
import { capability, foundation } from '../../capability';
import { InviteCodeItem } from './_shared';

export const SetInviteCodeLimitInput = z.strictObject({
  schoolId: z.string().uuid(),
  codeId: z.string().uuid(),
  /** Positive whole number of uses, or null for unlimited. */
  maxUses: z.number().int().positive().nullable(),
});
export type SetInviteCodeLimitInput = z.infer<typeof SetInviteCodeLimitInput>;

export const SetInviteCodeLimitResult = z.strictObject({
  inviteCode: InviteCodeItem,
});
export type SetInviteCodeLimitResult = z.infer<typeof SetInviteCodeLimitResult>;

/** ops.institutions.setInviteCodeLimit */
export const setInviteCodeLimit = foundation
  .errors({
    NOT_FOUND: {},
    CONFLICT: {},
  })
  .input(SetInviteCodeLimitInput)
  .output(SetInviteCodeLimitResult)
  .meta(capability({ kind: 'command' }));
