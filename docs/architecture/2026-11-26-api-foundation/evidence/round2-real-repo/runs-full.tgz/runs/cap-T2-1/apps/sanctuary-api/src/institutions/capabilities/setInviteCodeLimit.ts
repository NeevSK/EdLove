// ops.institutions.setInviteCodeLimit: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/setInviteCodeLimit.ts; the router and catalog are generated.
import { ORPCError } from '@orpc/server';
import type {
  InviteCodeItem,
  SetInviteCodeLimitInput,
  SetInviteCodeLimitResult,
} from '@repo/core/api/v1/contract';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

export async function run(
  db: PoolClient,
  accountId: string,
  input: SetInviteCodeLimitInput,
): Promise<SetInviteCodeLimitResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const current = await db.query<{ uses_count: number | null }>(
    `SELECT uses_count FROM public.invite_codes WHERE id = $1 AND school_id = $2 FOR UPDATE`,
    [input.codeId, input.schoolId],
  );
  const row = current.rows[0];
  if (!row) {
    throw new ORPCError('NOT_FOUND', { message: 'Invite code not found for this institution.' });
  }

  const usesCount = row.uses_count ?? 0;
  if (input.maxUses !== null && input.maxUses < usesCount) {
    throw new ORPCError('CONFLICT', {
      message: `maxUses cannot be lower than the ${usesCount} uses already made.`,
    });
  }

  const res = await db.query<{
    id: string;
    school_id: string;
    code: string;
    role: string;
    max_uses: number | null;
    uses_count: number | null;
    invitation_text: string | null;
    is_active: boolean;
    created_at: Date | string;
  }>(
    `UPDATE public.invite_codes SET max_uses = $3
     WHERE id = $1 AND school_id = $2
     RETURNING id, school_id, code, role, max_uses, uses_count, invitation_text, is_active, created_at`,
    [input.codeId, input.schoolId, input.maxUses],
  );
  const updated = res.rows[0];
  if (!updated) {
    throw new ORPCError('NOT_FOUND', { message: 'Invite code not found for this institution.' });
  }

  const inviteCode: InviteCodeItem = {
    id: updated.id,
    schoolId: updated.school_id,
    code: updated.code,
    role: updated.role,
    maxUses: updated.max_uses,
    usesCount: updated.uses_count ?? 0,
    invitationText: updated.invitation_text,
    isActive: updated.is_active,
    createdAt:
      typeof updated.created_at === 'string'
        ? updated.created_at
        : updated.created_at.toISOString(),
  };

  return { inviteCode };
}
