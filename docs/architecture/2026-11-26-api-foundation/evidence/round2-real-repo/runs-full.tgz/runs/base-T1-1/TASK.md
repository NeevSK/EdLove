# Task T1: read one invite code

Add a new query capability `ops.institutions.getInviteCode` to the v1 API.

- Input: `{ schoolId: uuid, codeId: uuid }`. Unknown fields are rejected.
- Output: `{ inviteCode: InviteCodeItem }` (the same item shape `listInviteCodes` returns), for active and inactive codes alike.
- Only someone with principal authority over the school may read it: otherwise `FORBIDDEN` (same rule as the other invite-code capabilities).
- If the code does not exist, or belongs to a different school than `schoolId`, return `NOT_FOUND`.
- It is a query, opened on the app channel like its neighbours, and must appear wherever the repository's own checks expect a capability to appear.

Keep every existing check passing. Run `./eval-check.sh` from the repository root until it prints `check: OK`.
