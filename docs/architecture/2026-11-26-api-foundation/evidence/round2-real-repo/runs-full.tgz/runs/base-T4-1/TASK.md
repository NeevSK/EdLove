# Task T4: invite codes that expire

Invite codes need an optional expiry.

- `createInviteCode` input accepts an optional `expiresAt`: an ISO 8601 date-time with offset, or `null`. Omitted means no expiry.
- `InviteCodeItem` (returned by `createInviteCode` and `listInviteCodes`) gains `expiresAt`: the ISO date-time string, or `null` when the code never expires.
- Store it in the `expires_at` column of `public.invite_codes` (timestamptz). Declare the field on the `InviteCode` model in `packages/schema/schema.zmodel` as `expires_at DateTime?`; the database column already exists in the test database.
- An invalid date-time string is rejected as invalid input.

Keep every existing check passing. Run `./eval-check.sh` from the repository root until it prints `check: OK`.
