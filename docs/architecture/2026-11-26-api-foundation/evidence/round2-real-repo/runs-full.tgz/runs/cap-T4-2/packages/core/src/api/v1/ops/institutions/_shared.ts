import { z } from 'zod';

export const InviteCodeItem = z.strictObject({
  id: z.string().uuid(),
  schoolId: z.string().uuid(),
  code: z.string(),
  role: z.string(),
  maxUses: z.number().int().nullable(),
  usesCount: z.number().int(),
  invitationText: z.string().nullable(),
  isActive: z.boolean(),
  createdAt: z.string(),
  expiresAt: z.string().nullable(),
});
export type InviteCodeItem = z.infer<typeof InviteCodeItem>;
