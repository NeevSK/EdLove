import { z } from 'zod';
import { capability, foundation } from '../../capability';
import { InviteCodeItem } from './_shared';

export const CreateInviteCodeInput = z.strictObject({
  schoolId: z.string().uuid(),
  role: z.enum(['teacher', 'student', 'staff', 'guardian']),
  maxUses: z.number().int().positive().nullable().optional(),
  invitationText: z.string().max(255).optional(),
  expiresAt: z.string().datetime({ offset: true }).nullable().optional(),
});
export type CreateInviteCodeInput = z.infer<typeof CreateInviteCodeInput>;

export const CreateInviteCodeResult = z.strictObject({
  inviteCode: InviteCodeItem,
});
export type CreateInviteCodeResult = z.infer<typeof CreateInviteCodeResult>;

/** ops.institutions.createInviteCode */
export const createInviteCode = foundation
  .input(CreateInviteCodeInput)
  .output(CreateInviteCodeResult)
  .meta(capability({ kind: 'command' }));
