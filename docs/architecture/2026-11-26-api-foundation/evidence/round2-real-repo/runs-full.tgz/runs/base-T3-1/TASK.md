# Task T3: make revoking an invite code honest

`ops.institutions.revokeInviteCode` currently answers `{ success: true }` even when nothing was revoked. Change it:

- If the code does not exist, or belongs to a different school than `schoolId`: `NOT_FOUND`, and nothing changes.
- If the code is already inactive: `CONFLICT`.
- Otherwise deactivate it and return `{ success: true }` as before.
- `FORBIDDEN` without principal authority stays as it is.
- Clients should be able to see from the contract that this capability can return `NOT_FOUND` and `CONFLICT`.

Update or add tests where the old behaviour was asserted. Keep every existing check passing. Run `./eval-check.sh` from the repository root until it prints `check: OK`.
