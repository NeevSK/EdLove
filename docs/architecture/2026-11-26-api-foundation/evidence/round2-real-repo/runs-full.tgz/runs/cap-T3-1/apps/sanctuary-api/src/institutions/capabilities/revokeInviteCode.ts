// ops.institutions.revokeInviteCode: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/revokeInviteCode.ts; the router and catalog are generated.
import type { RevokeInviteCodeInput, RevokeInviteCodeResult } from '@repo/core/api/v1/contract';
import { ORPCError } from '@orpc/server';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

export async function run(
  db: PoolClient,
  accountId: string,
  input: RevokeInviteCodeInput,
): Promise<RevokeInviteCodeResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const found = await db.query(
    `SELECT is_active FROM public.invite_codes WHERE id = $1 AND school_id = $2 FOR UPDATE`,
    [input.codeId, input.schoolId],
  );
  if (found.rowCount === 0) {
    throw new ORPCError('NOT_FOUND', {
      message: 'No invite code with that id exists for this school.',
    });
  }
  if (found.rows[0]?.is_active !== true) {
    throw new ORPCError('CONFLICT', { message: 'This invite code is already inactive.' });
  }

  await db.query(
    `UPDATE public.invite_codes SET is_active = false WHERE id = $1 AND school_id = $2`,
    [input.codeId, input.schoolId],
  );

  return { success: true };
}
