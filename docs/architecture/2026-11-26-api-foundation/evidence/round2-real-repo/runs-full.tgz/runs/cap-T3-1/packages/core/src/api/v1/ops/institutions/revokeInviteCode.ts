import { z } from 'zod';
import { capability, foundation } from '../../capability';

export const RevokeInviteCodeInput = z.strictObject({
  schoolId: z.string().uuid(),
  codeId: z.string().uuid(),
});
export type RevokeInviteCodeInput = z.infer<typeof RevokeInviteCodeInput>;

export const RevokeInviteCodeResult = z.strictObject({
  success: z.boolean(),
});
export type RevokeInviteCodeResult = z.infer<typeof RevokeInviteCodeResult>;

/** ops.institutions.revokeInviteCode */
export const revokeInviteCode = foundation
  .errors({
    NOT_FOUND: {},
    CONFLICT: {},
  })
  .input(RevokeInviteCodeInput)
  .output(RevokeInviteCodeResult)
  .meta(capability({ kind: 'command' }));
