// ops.institutions.getInviteCode: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/getInviteCode.ts; the router and catalog are generated.
import { ORPCError } from '@orpc/server';
import type { GetInviteCodeInput, GetInviteCodeResult } from '@repo/core/api/v1/contract';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

export async function run(
  db: PoolClient,
  accountId: string,
  input: GetInviteCodeInput,
): Promise<GetInviteCodeResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const res = await db.query<{
    id: string;
    school_id: string;
    code: string;
    role: string;
    max_uses: number | null;
    uses_count: number | null;
    invitation_text: string | null;
    is_active: boolean;
    created_at: Date | string;
  }>(
    `SELECT id, school_id, code, role, max_uses, uses_count, invitation_text, is_active, created_at
     FROM public.invite_codes
     WHERE id = $1 AND school_id = $2`,
    [input.codeId, input.schoolId],
  );

  const row = res.rows[0];
  if (!row) {
    throw new ORPCError('NOT_FOUND');
  }

  return {
    inviteCode: {
      id: row.id,
      schoolId: row.school_id,
      code: row.code,
      role: row.role,
      maxUses: row.max_uses,
      usesCount: row.uses_count ?? 0,
      invitationText: row.invitation_text,
      isActive: row.is_active,
      createdAt: typeof row.created_at === 'string' ? row.created_at : row.created_at.toISOString(),
    },
  };
}
