import { z } from 'zod';
import { capability, foundation } from '../../capability';
import { InviteCodeItem } from './_shared';

export const GetInviteCodeInput = z.strictObject({
  schoolId: z.string().uuid(),
  codeId: z.string().uuid(),
});
export type GetInviteCodeInput = z.infer<typeof GetInviteCodeInput>;

export const GetInviteCodeResult = z.strictObject({
  inviteCode: InviteCodeItem,
});
export type GetInviteCodeResult = z.infer<typeof GetInviteCodeResult>;

/** ops.institutions.getInviteCode */
export const getInviteCode = foundation
  .errors({ NOT_FOUND: {} })
  .input(GetInviteCodeInput)
  .output(GetInviteCodeResult)
  .meta(capability({ kind: 'query' }));
