# Task T2: change an invite code's use limit

Add a new command capability `ops.institutions.setInviteCodeLimit` to the v1 API.

- Input: `{ schoolId: uuid, codeId: uuid, maxUses: positive integer | null }`. `null` means unlimited. Unknown fields are rejected; 0, negative or fractional `maxUses` is rejected as invalid input.
- Output: `{ inviteCode: InviteCodeItem }` with the new limit.
- `FORBIDDEN` without principal authority over the school (same rule as the other invite-code capabilities).
- `NOT_FOUND` if the code does not exist or belongs to another school.
- `CONFLICT` if `maxUses` is lower than the code's current `usesCount` (equal is allowed). Nothing is changed in that case.
- It is a command, opened on the app channel like its neighbours, and must appear wherever the repository's own checks expect a capability to appear.

Keep every existing check passing. Run `./eval-check.sh` from the repository root until it prints `check: OK`.
