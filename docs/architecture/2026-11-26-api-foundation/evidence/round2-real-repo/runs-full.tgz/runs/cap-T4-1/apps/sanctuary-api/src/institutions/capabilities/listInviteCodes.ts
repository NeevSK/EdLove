// ops.institutions.listInviteCodes: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/listInviteCodes.ts; the router and catalog are generated.
import type {
  InviteCodeItem,
  ListInviteCodesInput,
  ListInviteCodesResult,
} from '@repo/core/api/v1/contract';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

function toIsoOrNull(value: Date | string | null | undefined): string | null {
  if (value == null) return null;
  return typeof value === 'string' ? value : value.toISOString();
}

export async function run(
  db: PoolClient,
  accountId: string,
  input: ListInviteCodesInput,
): Promise<ListInviteCodesResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const res = await db.query<{
    id: string;
    school_id: string;
    code: string;
    role: string;
    max_uses: number | null;
    uses_count: number | null;
    invitation_text: string | null;
    is_active: boolean;
    created_at: Date | string;
    expires_at?: Date | string | null;
  }>(
    `SELECT id, school_id, code, role, max_uses, uses_count, invitation_text, is_active, created_at, expires_at
     FROM public.invite_codes
     WHERE school_id = $1
     ORDER BY created_at DESC`,
    [input.schoolId],
  );

  const inviteCodes: InviteCodeItem[] = res.rows.map((row) => ({
    id: row.id,
    schoolId: row.school_id,
    code: row.code,
    role: row.role,
    maxUses: row.max_uses,
    usesCount: row.uses_count ?? 0,
    invitationText: row.invitation_text,
    isActive: row.is_active,
    createdAt: typeof row.created_at === 'string' ? row.created_at : row.created_at.toISOString(),
    expiresAt: toIsoOrNull(row.expires_at),
  }));

  return { inviteCodes };
}
