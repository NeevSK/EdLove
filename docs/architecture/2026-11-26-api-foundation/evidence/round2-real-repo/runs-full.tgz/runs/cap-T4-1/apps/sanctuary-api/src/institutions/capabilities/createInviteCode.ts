// ops.institutions.createInviteCode: the server side of this capability. The contract is in
// packages/core/src/api/v1/ops/institutions/createInviteCode.ts; the router and catalog are generated.

import { randomUUID } from 'node:crypto';
import type {
  CreateInviteCodeInput,
  CreateInviteCodeResult,
  InviteCodeItem,
} from '@repo/core/api/v1/contract';
import type { PoolClient } from 'pg';
import { assertSchoolAuthority } from './_shared';

export async function run(
  db: PoolClient,
  accountId: string,
  input: CreateInviteCodeInput,
): Promise<CreateInviteCodeResult> {
  await assertSchoolAuthority(db, accountId, input.schoolId);

  const suffixMap: Record<CreateInviteCodeInput['role'], string> = {
    teacher: 'TEACH',
    student: 'STUDY',
    staff: 'STAFF',
    guardian: 'GUARD',
  };
  const suffix = suffixMap[input.role] || 'MEMBER';
  const randomPart = randomUUID()
    .replace(/[^a-zA-Z0-9]/g, '')
    .slice(0, 6)
    .toUpperCase();
  const code = `GURU-${randomPart}-${suffix}`;

  const id = randomUUID();
  const createdAt = new Date().toISOString();
  const expiresAt = input.expiresAt ? new Date(input.expiresAt).toISOString() : null;

  await db.query(
    `INSERT INTO public.invite_codes
       (id, school_id, code, role, max_uses, uses_count, invitation_text, created_by, is_active, created_at, expires_at)
     VALUES ($1, $2, $3, $4, $5, 0, $6, $7, true, clock_timestamp(), $8)`,
    [
      id,
      input.schoolId,
      code,
      input.role,
      input.maxUses ?? null,
      input.invitationText ?? null,
      accountId,
      expiresAt,
    ],
  );

  const inviteCode: InviteCodeItem = {
    id,
    schoolId: input.schoolId,
    code,
    role: input.role,
    maxUses: input.maxUses ?? null,
    usesCount: 0,
    invitationText: input.invitationText ?? null,
    isActive: true,
    createdAt,
    expiresAt,
  };

  return { inviteCode };
}
